<h2 class="mb-2">Registrations & Reports</h2>
	

<?php if(session('status')): ?>
	<div class="alert alert-success" role="alert">
		<?php echo e(session('status')); ?>

	</div>
<?php endif; ?>



<form method="POST" action="/admin/display/registrations">
	<?php echo csrf_field(); ?>

	<div class="card mb-4">
		<div class="card-header">Search Registration</div>
		<div class="card-body">
			<p>
				To search the Registration list, please enter your search criteria 
				below.
			</p>

			<div class="row  mb-3">
				<div class="col-5">
					<input class="form-control <?php $__errorArgs = ['search_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="search_first_name" value="<?php echo e(old("search_first_name", $search["first_name"])); ?>" placeholder="Search First Name">
					<?php $__errorArgs = ['search_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="col-5">
					<input class="form-control <?php $__errorArgs = ['search_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="search_last_name" value="<?php echo e(old("search_last_name", $search["last_name"])); ?>" placeholder="Search Last Name">
					<?php $__errorArgs = ['search_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="col-auto">
					<button class="btn btn-primary" style="width: 100px;" type="submit" name="btn_search">Search</button>
				</div>
			</div>

			<div class="row">
				<div class="col-5">
					<input class="form-control <?php $__errorArgs = ['search_check_in'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="search_check_in" value="<?php echo e(old("search_check_in", $search["check_in"])); ?>" placeholder="Search Check In Date">
					<?php $__errorArgs = ['search_check_in'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="col-5">
					<input class="form-control <?php $__errorArgs = ['search_check_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="search_check_out" value="<?php echo e(old("search_check_out", $search["check_out"])); ?>" placeholder="Search Check Out Date">
					<?php $__errorArgs = ['search_check_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
		
				<div class="col-auto">
					<a class="btn btn-success" style="width: 100px;" href="/admin/display/registrations">Reset</a>
				</div>
			</div>
		</div>
	</div>


	<div class="card mb-3">
		<div class="card-header">
			<div class="row">
				<div class="col-6">Registration List</div>
				<div class="col-6 text-right">
					Showing <?php echo e($registrations->firstItem()); ?> - <?php echo e($registrations->lastItem()); ?>

					of <?php echo e($registrations->total()); ?>

				</div>
			</div>
		</div>
		<div class="card-body">
			<table class="w-100">
				<tr>
					<th style="width: 40%">Name</th>
					<th>Course</th>
					<th class="text-center">Check In</th>
					<th class="text-center">Check Out</th>
					<th class="text-center">Actions</th>
				</tr>
				<?php if(!empty($registrations[0])): ?>
					<?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($registration->first_name . " " . $registration->last_name); ?></td>
							<td><?php echo e($registration->course_num); ?></td>
							<td class="text-center"><?php echo e(date("m/d/Y", strtotime($registration->check_in_date))); ?></td>
							<td class="text-center"><?php echo e(date("m/d/Y", strtotime($registration->check_out_date))); ?></td>
							<td class="text-center">
								<a href="/registration/<?php echo e($registration->confirmation_num); ?>/<?php echo e($registration->id); ?>/edit/admin">
									<i class="fas fa-pencil-alt"></i>
								</a>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
				<?php else: ?>
					<tr><td>&nbsp</td></tr>
					<tr>
						<td class="text-danger text-center" colspan="5">
							--- No Registrations Were Found ---
						</td>
					</tr>
					<tr><td>&nbsp</td></tr>
				<?php endif; ?>
			</table>
		</div>
	</div>

	<div class="d-flex justify-content-end mb-4">
		<?php echo e($registrations->onEachSide(2)
							->appends([
								"fn" => $search["first_name"],
								"ln" => $search["last_name"],
								"ci" => strtotime($search["check_in"]),
								"co" => strtotime($search["check_out"]),
							])
							->links()); ?>

	</div>



	<div class="card mb-4">
		<div class="card-header">Reports</div>
		<div class="card-body">
			<p>
				To download a CSV Report of Registration information please complete a 
				search for the data you are looking for above and then click the 
				"Download Report" button.
			</p>

			<div class="text-right">
				<button class="btn btn-primary" type="submit" name="btn_report">Download Report</div>
			</div>
		</div>
	</div>
</form>
	<?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/admin/partials/_registrations.blade.php ENDPATH**/ ?>