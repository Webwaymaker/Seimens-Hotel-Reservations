<h2><?php if($custom): ?> Custom <?php endif; ?> Siemens Training Registration Report</h2>

<p>Hello,</p>

<?php if(empty($registrations)): ?>
	<p>An attempt was made to run the Siemens Training Registration Report but...</p>
	<p><strong>There are no new registrations to report for this day.</strong></p>

<?php else: ?> 
	<p>
		<?php if($custom): ?> 
			Here is the custom Siemens Training Registration Report that you requested.
		<?php else: ?>
			Here is the daily Siemens Training Registration Report. 
		<?php endif; ?> 
	</p>

	<?php if(count($registrations) > 5): ?>
		<p>
			The table of registrations is not shown in the body of this email because
			the number of registration requested to be displayed exceeded 150.
		</p> 

	<?php else: ?>
		<p>
			You can click on a registrants name below to see more details about the 
			registration.
		</p> 

		<table style="width: 100%">
			<tr>
				<th style="width: 50%; text-align: left;">Name</th>
				<th style="width: 20%; text-align: left;">Course</th>
				<th style="width: 15%">Check In Date</th>
				<th style="width: 15%">Check Out Date</th>
			</tr>

			<?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td>
						<a href= "<?php echo e($base_url); ?>/registration/<?php echo e($registration["confirmation_num"]); ?>/<?php echo e($registration["id"]); ?>/edit/admin">
							<?php echo e($registration["first_name"] . " " . $registration["last_name"]); ?>

						</a>
					</td>
					<td><?php echo e($registration["course_num"]); ?></td>
					<td style="text-align: center;"><?php echo e($registration["check_in_date"]); ?></td>
					<td style="text-align: center;"><?php echo e($registration["check_out_date"]); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	<?php endif; ?>
<?php endif; ?>

<p>
	<small>
		Please do not respond to this email it will go to an email box that is not 
		monitored.
	</small>
</p><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/emails/registration_report_mail.blade.php ENDPATH**/ ?>