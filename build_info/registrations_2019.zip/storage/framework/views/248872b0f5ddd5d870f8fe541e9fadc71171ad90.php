<form method="POST" action="/registration/<?php echo e($conf_num); ?>/<?php echo e($id); ?>/delete">
	<?php echo csrf_field(); ?>
	<?php echo method_field("delete"); ?>
	<button class="btn btn-danger mt-2" type="submit" name="btn_cancel">Cancel Registration</button> 
</form>
<?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/registrations/partials/_cancel_reg_btn_form.blade.php ENDPATH**/ ?>