<table width="100%">
	<tr>
		<td>First Name</td>
		<td>
			<input class="form-control" type="text" name="first_name" value="<?php echo e(old('first_name', (isset($reg_data->first_name)) ? $reg_data->first_name : '')); ?>">
		</td>
	</tr>
	<tr>
		<td>Last Name</td>
		<td>
			<input class="form-control" type="text" name="last_name" value="<?php echo e(old('last_name', (isset($reg_data->last_name)) ? $reg_data->last_name : '')); ?>">
		</td>
	</tr>
	<tr>
		<td>Email</td>
		<td>
			<input class="form-control" type="text" name="email" value="<?php echo e(old('email', (isset($reg_data->email)) ? $reg_data->email : '')); ?>">
		</td>
	</tr>
	<tr>
		<td>Mobile Number</td>
		<td>
			<input class="form-control" type="text" name="mobile_num" value="<?php echo e(old('mobile_num', (isset($reg_data->mobile_num)) ? $reg_data->mobile_num : '')); ?>">
		</td>
	</tr>
	<tr><td>&nbsp;</td></tr>

	<tr>
		<td>Location</td>
		<td>
			<input class="form-control" type="text" name="location" value="<?php echo e(old('location', (isset($reg_data->location)) ? $reg_data->location : '')); ?>">
		</td>
	</tr>
	<tr>
		<td>Course</td>
		<td>
			<input class="form-control" type="text" name="course_num" value="<?php echo e(old('course_num', (isset($reg_data->course_num)) ? $reg_data->course_num : '')); ?>">
		</td>
	</tr>
	<tr><td>&nbsp;</td></tr>

	<tr>
		<td>Check In Date</td>
		<td>
			<input class="form-control" type="text" name="check_in_date" value="<?php echo e(old('check_in_date', (isset($reg_data->check_in_date)) ? $reg_data->check_in_date : '')); ?>">
		</td>
	</tr>
	<tr>
		<td>Check Out Date</td>
		<td>
			<input class="form-control" type="text" name="check_out_date" value="<?php echo e(old('check_out_date', (isset($reg_data->check_out_date)) ? $reg_data->check_out_date : '')); ?>">
		</td>
	</tr>
	<tr><td>&nbsp;</td></tr>

	<tr>
		<td>Special Requests</td>
		<td>
			<textarea class="form-control" name="special_req"><?php echo e(old('special_req', (isset($reg_data->special_req)) ? $reg_data->special_req : '')); ?></textarea>
		</td>
	</tr>
	<tr>
		<td>Handicapped Accessable</td>
		<td>
			<select class="form-control" name="handicapped">
				<option value="0" <?php echo e(old("handicapped", (isset($reg_data->handicapped)) ? $reg_data->handicapped : -1) == 'No'  ? 'selected' : ''); ?>>No</option>
				<option value="1" <?php echo e(old("handicapped", (isset($reg_data->handicapped)) ? $reg_data->handicapped : -1) == 'Yes' ? 'selected' : ''); ?>>Yes</option>
			</select>
		</td>
	</tr>
	<tr><td>&nbsp;</td></tr>
</table>
<?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/registrations/partials/_registration_form.blade.php ENDPATH**/ ?>