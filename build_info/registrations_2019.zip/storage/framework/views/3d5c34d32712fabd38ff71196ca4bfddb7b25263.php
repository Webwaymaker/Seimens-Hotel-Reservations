 
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Edit / Cancel Registration</div>

				<div class="card-body">
					<h3>Success</h3>

					<p>
						An email has been sent to <?php echo e($email); ?>.  With all the confirmation
						numbers associated to the address.
					</p>

					<div class="text-right">
						<a href="/registration_login">Return to Edit Registration</a>
					</div>
				</div>					
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/forgot_conf_num_success.blade.php ENDPATH**/ ?>