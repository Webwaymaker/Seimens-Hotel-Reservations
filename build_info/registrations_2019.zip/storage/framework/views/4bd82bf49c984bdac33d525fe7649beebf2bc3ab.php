<h2>Siemens - Administrator Passsword Reset</h2>

<p>
	This is a request to reset you password for the Siemen's Hotel Registration 
	system.  This request will only be valid for 60 minutes.
</p>  

<p>
	<a href="https://corpcoach/registration/admin/reset/<?php echo e(time()); ?>/<?php echo e($admin->access_token); ?>/<?php echo e($admin->id); ?>">
		Please click here to reset your password
	</a>
</p>

<p>
	If you are not expecting this email please contact the administrator for the 
	Siemen's Hotel Registration system
</p><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/emails/admin_password_reset_mail.blade.php ENDPATH**/ ?>