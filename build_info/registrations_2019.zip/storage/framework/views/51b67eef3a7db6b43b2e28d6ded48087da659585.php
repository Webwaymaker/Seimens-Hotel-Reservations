 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
				<div class="text-right mb-2">
					<a href="/registration_login">Click to modify or delete an existing Registration</a>
				</div>
				
				<div class="card">
					<div class="card-header">Hotel Registration</div>
					<div class="card-body">
					  <div class="alert alert-info">
							<h3>Important</h3>
							<ul>
								<li>
									For our Customers and Partners, please complete this form to
									make hotel reservations. <u>You will receive a confirmation
									email on the Thursday before your class beings</u>.
								</li>

								<li>
									If you are a Siemens BT or Siemens Canada employee,
									<span style="font-weight: bold;">DO NOT</span> complete this form. Your
									hotel reservations will automatically be made for you.
								</li>

								<li>
									For questions, contact BT University at
									<a href="mailto: btuniversity.i-bt@siemens.com">btuniversity.i-bt@siemens.com</a>.
								</li>
							</ul>
						</div>
										  
						<?php if($errors->any()): ?>
							<div class="alert alert-danger">
								<ul>
									<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php echo e($error); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						<?php endif; ?>

						<form method="POST" action="/registration">
							<?php echo csrf_field(); ?>

							<?php echo $__env->make('registrations.partials._registration_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

							<div class="text-right">
								<button class="btn btn-primary" type="submit" name="btn_edit">Register</button> 
							</div>
						</form>
					 </div>
					 
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
	$(function () {
		$('#datetimepicker1').datetimepicker();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/registrations/registration.blade.php ENDPATH**/ ?>