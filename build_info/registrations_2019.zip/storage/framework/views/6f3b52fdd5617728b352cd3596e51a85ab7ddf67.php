<h2>Siemens Registration</h2>

<p>Thank you for your registration it has been successfully submitted.</p> 

<p>Your confirmation number is <strong><?php echo e($registration->confirmation_num); ?></strong> </p>

<h3>Your Registration Details...</h3>

<table>
	<tr>
		<td>First Name: </td>
		<td><?php echo e($registration->first_name); ?></td>
	</tr>
	<tr>
		<td>Last Name: </td>
		<td><?php echo e($registration->last_name); ?></td>
	</tr>
	<tr>
		<td>Email Address: </td>
		<td><?php echo e($registration->email); ?></td>
	</tr>
	<tr>
		<td>Mobile Number: </td>
		<td><?php echo e($registration->mobile_num); ?></td>
	</tr>
	<tr>
		<td>Location: </td>
		<td><?php echo e($registration->location); ?></td>
	</tr>
	<tr>
		<td>Course Number: </td>
		<td><?php echo e($registration->course_num); ?></td>
	</tr>
	<tr>
		<td>Check In Date: </td>
		<td><?php echo e($registration->check_in_date); ?></td>
	</tr>
	<tr>
		<td>Check Out Data: </td>
		<td><?php echo e($registration->check_out_date); ?></td>
	</tr>
	<tr>
		<td>Handicapped Accessible: </td>
		<td><?php echo e(($registration->handicapped) ? "Yes" : "No"); ?></td>
	</tr>
	<tr>
		<td>Special Requests: </td>
		<td><?php echo e($registration->special_req); ?></td>
	</tr>
</table>

<p>
	If you would like to Edit or Cancel your registration please click
	<a href="/registration/<?php echo e($registration->confirmation_num); ?>/<?php echo e($registration->id); ?>/edit">Here</a>.
</p>

<p>Enjoy your stay!</p>
<?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/emails/registration_conf_mail.blade.php ENDPATH**/ ?>