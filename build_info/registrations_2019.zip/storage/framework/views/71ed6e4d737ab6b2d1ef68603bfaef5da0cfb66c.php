 
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">

		<div class="col-md-3">
			<div class="card mb-4">
				<div class="card-header">Manage</div>
				<div class="card-body">
					<a href="/admin/display/registrations">Registrations & Reports</a><br />
					<a href="/admin/display/administrators">Administrators</a><br />
					<a href="/admin/display/report_tos">Report-Tos</a><br />
					<a href="/admin/display/blackouts">Blackouts</a>
				</div>
			</div>
		</div>

		<div class="col-md-9">
			<?php if($display == "administrators"): ?>
				<?php echo $__env->make("admin.partials._administrators", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<?php elseif($display == "report_tos"): ?>
				<?php echo $__env->make("admin.partials._report_tos", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<?php elseif($display == "blackouts"): ?>
				<?php echo $__env->make("admin.partials._blackouts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<?php else: ?>
				<?php echo $__env->make("admin.partials._registrations", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>
		</div>
	</div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/admin/admin.blade.php ENDPATH**/ ?>