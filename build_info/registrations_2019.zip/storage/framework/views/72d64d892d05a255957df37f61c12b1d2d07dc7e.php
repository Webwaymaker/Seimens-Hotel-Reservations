 
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Edit / Cancel Registration</div>

				<div class="card-body">
					<h3>Confirmation Number Recovery</h3>

					<p>
						To recover your confirmation number(s) please enter your email address 
						below.&nbsp; All registration confirmation numbers that are associated 
						to the entered email address will be sent to this email 
						address.
					</p>


					<?php if($errors->any()): ?>
						<div class="alert alert-danger mb-4">
							<ul>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					<?php endif; ?>

					<?php if(isset($invalid)): ?>
						<div class="alert alert-danger mb-4">
							The email address you entered is was not found.&nbsp; Please 
							check the spelling of the email address or enter a new 
							email address.  
						</div>	
					<?php endif; ?>

					<form method="POST" action="/forgot">
						<?php echo csrf_field(); ?>

						<table class="w-100">
							<tr>
								<td width="30%">Email Address</td>
								<td width="70%">
									<input class="form-control" type="text" name="email" value="<?php echo e(old('email', (isset($email)) ? $email : '')); ?>">
								</td>
							</tr>
							<tr><td>&nbsp;</td></tr>							

							<tr>
								<td class="text-right" colspan="2">
									<button class="btn btn-primary" type="submit">Recover</div>
								</td>
							</tr>
						</table>
					</form>

				</div>					
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/forgot_conf_num.blade.php ENDPATH**/ ?>