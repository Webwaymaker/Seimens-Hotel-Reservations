<h2 class="mb-2">Manage Blackouts</h2>


<?php if(session('status')): ?>
	<div class="alert alert-success" role="alert">
		<?php echo e(session('status')); ?>

	</div>
<?php endif; ?>


<div class="card mb-4">
	<div class="card-header">Add A New Blackout</div>
	<div class="card-body">
		<p>
			<small>
				To set a new Blackout provide, the activation date&nbsp; 
				(This is the date that you would first like customers to be made 
				aware of the Blackout).&nbsp; Set the start and end date of the 
				Blackout.&nbsp; Then give the Blackout a descriptor that the customer 
				will see so they can understand why the dates are not available.
			</small>
		</p>
		<form method="post" action="/admin/blackout">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="current_date" value="<?php echo e(date("m/d/Y")); ?>" />
			<div class="row mb-3">
				<div class="col-4">
					<input class="form-control <?php $__errorArgs = ['activate_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="activate_date" value="<?php echo e(old("activate_date")); ?>" placeholder="Activation Date">
					<?php $__errorArgs = ['activate_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="col-4">
					<input class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="start_date" value="<?php echo e(old("start_date")); ?>" placeholder="Blackout Start Date">
					<?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="col-4">
					<input class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="end_date" value="<?php echo e(old("end_date")); ?>" placeholder="Blackout End Date">
					<?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>

			<div class="row">
				<div class="col">
					<input class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="description" value="<?php echo e(old("description")); ?>" placeholder="Blackout Description">
					<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="col-auto">
					<button class="btn btn-primary" type="submit">Add</button>
				</div>
			</div>
		</form>
	</div>
</div>


<div class="card mb-4">
	<div class="card-header">Blackout Dates</div>
	<div class="card-body">
		<table class="w-100">
			<tr>
				<th class="w-50">Description</th>
				<th class="text-center">Activate Date</th>
				<th class="text-center">Start Date</th>
				<th class="text-center">End Date</th>
				<th class="text-center">Actions</th>
			</tr>
			<?php if(!empty($blackout_dates[0])): ?>
				<?php $__currentLoopData = $blackout_dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blackout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($blackout->description); ?></td>
						<td class="text-center"><?php echo e($blackout->activate_at); ?></td>
						<td class="text-center"><?php echo e($blackout->start_at); ?></td>
						<td class="text-center"><?php echo e($blackout->end_at); ?></td>
						<td class="text-center">
							<a href="/admin/blackout/<?php echo e($blackout->access_token); ?>/<?php echo e($blackout->id); ?>/delete">
								<i class="fas fa-pencil-alt"></i>
							</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			<?php else: ?>
				<tr><td>&nbsp</td></tr>
				<tr>
					<td class="text-danger text-center" colspan="5">
						--- No Active Blackout Dates Were Found ---
					</td>
				</tr>
				<tr><td>&nbsp</td></tr>
			<?php endif; ?>
		</table>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/admin/partials/_blackouts.blade.php ENDPATH**/ ?>