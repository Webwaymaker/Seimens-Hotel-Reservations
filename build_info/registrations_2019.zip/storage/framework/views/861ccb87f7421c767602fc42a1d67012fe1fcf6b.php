 
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Hotel Registration</div>

				<div class="card-body">
					<h3>Success</h3>

					<p>
						Your registration was successfully updated.
					</p>
					<p>
						A new confirmation email has been sent to you.  As a reminder 
						you will also receive another email on the Thursday before your 
						class begins.
					</p>
					<p>
						Your confirmation number is still:  <strong><?php echo e($registration->confirmation_num); ?></strong>
					</p>
					<p>
						If you would like to continue modify or cancel your registration please click 
						<a href="/registration/<?php echo e($registration->confirmation_num); ?>/<?php echo e($registration->id); ?>/edit">
							here
						</a>.	
					</p>	
				</div>					
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/registration_update_success.blade.php ENDPATH**/ ?>