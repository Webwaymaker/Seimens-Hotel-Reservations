<h2 class="mb-2">Manage Administrators</h2>
			
<?php if(session('status')): ?>
	<div class="alert alert-success" role="alert">
		<?php echo e(session('status')); ?>

	</div>
<?php endif; ?>

<div class="card mb-4">
	<div class="card-header">Add A New Adminstrators</div>
	<div class="card-body">
		<p>
			<small>
				Once an adminstrator has been added an email will be sent
				to the admin's email address asking them to set thier 
				password.
			</small>
		</p>
		<form method="POST" action="/admin/add/admin">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col">
					<input class="form-control <?php $__errorArgs = ['admin_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="admin_name" value="<?php echo e(old("admin_name")); ?>" placeholder="Admin Name">
					<?php $__errorArgs = ['admin_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="col-7">
					<input class="form-control <?php $__errorArgs = ['admin_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="admin_email" value="<?php echo e(old("admin_email")); ?>" placeholder="Admin Email Address">
					<?php $__errorArgs = ['admin_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<small class="text-danger"><?php echo e($message); ?></small>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="col-auto text-right">
					<button class="btn btn-primary" type="submit">Add</button>
				</div>
			</div>
		</form>
	</div>
</div>

<div class="card mb-4">
	<div class="card-header">Adminstrator List</div>
	<div class="card-body">
		<table class="w-100">
			<tr>
				<th>Name</th>
				<th>Email Address</th>
				<th class="text-center">Actions</th>
			</tr>
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($user->name); ?></td>
					<td><?php echo e($user->email); ?></td>
					<td class="text-center">
						<a href="/admin/<?php echo e($user->access_token); ?>/<?php echo e($user->id); ?>/delete">
							<i class="fas fa-pencil-alt"></i>
						</a>
						&nbsp;
						<a href="/admin/password/<?php echo e($user->access_token); ?>/<?php echo e($user->id); ?>/reset">
							<i class="fas fa-key"></i>
						</a>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</table>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/admin/partials/_administrators.blade.php ENDPATH**/ ?>