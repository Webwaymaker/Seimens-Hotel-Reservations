 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
				<div class="card">
					<div class="card-header">Hotel Registration - Update</div>
					<div class="card-body">
					  <div class="alert alert-info">
							<h3>Important</h3>
							<ul>
								<li>
									Registrations updates may not process if within 24 hours
									of the registration's check in date. 									
								</li>

								<li>
									If you have any questions or need assistance, contact 
									BT University at ...<br />
									<a href="mailto: btuniversity.i-bt@siemens.com">btuniversity.i-bt@siemens.com</a>.
								</li>

								<li>
									If youwould like to cancel your registration please click here
									<form method="POST" action="/registration/<?php echo e($conf_num); ?>/<?php echo e($id); ?>/delete">
										<?php echo csrf_field(); ?>
										<?php echo method_field("delete"); ?>
										<button class="btn btn-danger mt-2" type="submit" name="btn_cancel">Cancel Registration</button> 
									</form>
								</li>
							</ul>
						</div>
										  
						<?php if($errors->any()): ?>
							<div class="alert alert-danger">
								<ul>
									<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php echo e($error); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						<?php endif; ?>

						<form method="POST" action="/registration/<?php echo e($conf_num); ?>/<?php echo e($id); ?>">
							<?php echo csrf_field(); ?>
							<?php echo method_field("put"); ?>

							<?php echo $__env->make('_registration_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

							<div class="text-right">
								<button class="btn btn-primary" type="submit" name="btn_update">Update Registration</button> 
							</div>
						</form>
					 </div>
					 
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
	$(function () {
		$('#datetimepicker1').datetimepicker();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/registration_update.blade.php ENDPATH**/ ?>