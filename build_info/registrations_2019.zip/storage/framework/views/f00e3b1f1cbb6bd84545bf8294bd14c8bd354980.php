 
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Administrator Account</div>

				<div class="card-body">
					<h3>Administrator Account Password Reset</h3>

					<p>
						To reset you password for the Siemen's Hotel Registration system
						Please enter a new and matching confirmation Password. 
					</p> 

					<?php if($errors->any()): ?>
						<div class="alert alert-danger mb-4">
							<ul>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					<?php endif; ?>

					<form class="mb-4" method="POST" action="/admin/set">
						<?php echo csrf_field(); ?>

						<input type="hidden" name="id" value="<?php echo e(old("id", $admin->id)); ?>" />
						<input type="hidden" name="access_token" value="<?php echo e(old("access_token", $admin->access_token)); ?>" />

						<table class="w-100">
							<tr>
								<td style="width: 25%">New Password</td>
								<td style="sidth: 75%">
									<input class="form-control" type="password" name="new_password" value="<?php echo e(old("new_password")); ?>" />
								</td>
							</tr>
							<tr>
								<td>Confirmation</td>
								<td>
									<input class="form-control" type="password" name="conf_password" value="<?php echo e(old("conf_password")); ?>" />
								</td>
							</tr>
							<tr>
								<td class="text-right" colspan="2">
									<small>Your new passord must be between 10 and 20 characters in length.</small>
								</td>
							</tr>
							<tr>
								<td class="text-right" colspan="2">
									<button class="btn btn-primary" type="submit">Set Password</button>
								</td>
							</tr>
						</table>
					</form>
					
				</div>					
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\webwaymaker\corprate_coach\registrations_2019\resources\views/admin/reset_password.blade.php ENDPATH**/ ?>